package com.easyplexdemoapp.di;

/**
 * Marks an activity / fragment injectable.
 *
 * @author Yobex.
 */
public interface Injectable {
}
