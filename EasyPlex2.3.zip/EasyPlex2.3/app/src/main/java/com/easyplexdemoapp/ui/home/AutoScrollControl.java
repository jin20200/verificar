package com.easyplexdemoapp.ui.home;

public interface AutoScrollControl {
    void pauseAutoScroll();
    void resumeAutoScroll();
}