package com.easyplexdemoapp.ui.mylist;


public interface DeleteFavoriteDetectListner {

    void onMediaDeletedSuccess(boolean clicked);

}
