/*
 * Copyright 2019 Google LLC. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.easyplexdemoapp.ui.player.cast.queue;

import static com.google.android.gms.cast.MediaStatus.*;

import android.content.Context;

import androidx.annotation.NonNull;

import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import timber.log.Timber;

/**
 * A singleton to manage the queue. Upon instantiation, it syncs up its own copy of the queue with
 * the one that the VideoCastManager holds. After that point, it maintains an up-to-date version of
 * the queue. UI elements get their data from this class. A boolean field, {@code mDetachedQueue}
 * is used to manage whether this changes to the queue coming from the cast framework should be
 * reflected here or not; when in "detached" mode, it means that its own copy of the queue is not
 * kept up to date with the one that the cast framework has. This is needed to preserve the queue
 * when the media session ends.
 */
public class QueueDataProvider {

    private static final String TAG = "QueueDataProvider";
    public static final int INVALID = -1;
    private final Context mAppContext;
    private final List<MediaQueueItem> mQueue = new CopyOnWriteArrayList<>();
    private static QueueDataProvider mInstance;
    // Locks modification to the remove queue.
    private final Object mLock = new Object();
    private final RemoteMediaClient.Callback mRemoteMediaClientCallback =
            new MyRemoteMediaClientCallback();
    private int mRepeatMode;
    private final boolean mShuffle;
    private MediaQueueItem mCurrentIem;
    private MediaQueueItem mUpcomingItem;
    private OnQueueDataChangedListener mListener;
    private boolean mDetachedQueue = true;

    private QueueDataProvider(Context context) {
        mAppContext = context.getApplicationContext();
        mRepeatMode = REPEAT_MODE_REPEAT_OFF;
        mShuffle = false;
        mCurrentIem = null;
        SessionManagerListener<CastSession> mSessionManagerListener = new MySessionManagerListener();
        CastContext.getSharedInstance(mAppContext).getSessionManager().addSessionManagerListener(
                mSessionManagerListener, CastSession.class);
        syncWithRemoteQueue();
    }

    public void onUpcomingStopClicked(MediaQueueItem upcomingItem) {
        RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null) {
            return;
        }
        // need to truncate the queue on the remote device so that we can complete the playback of
        // the current item but not go any further. Alternatively, one could just stop the playback
        // here, if that was acceptable.
        int position = getPositionByItemId(upcomingItem.getItemId());
        int[] itemIds = new int[getCount() - position];
        for (int i = 0; i < itemIds.length; i++) {
            itemIds[i] = mQueue.get(i + position).getItemId();
        }
        remoteMediaClient.queueRemoveItems(itemIds, null);
    }

    public void onUpcomingPlayClicked(MediaQueueItem upcomingItem) {
        RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null) {
            return;
        }
        remoteMediaClient.queueJumpToItem(upcomingItem.getItemId(), null);
    }

    public boolean isQueueDetached() {
        return mDetachedQueue;
    }

    public int getPositionByItemId(int itemId) {
        if (mQueue.isEmpty()) {
            return INVALID;
        }
        for (int i = 0; i < mQueue.size(); i++) {
            if (mQueue.get(i).getItemId() == itemId) {
                return i;
            }
        }
        return INVALID;
    }

    public static synchronized QueueDataProvider getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new QueueDataProvider(context);
        }
        return mInstance;
    }

    public void removeFromQueue(int position) {
        synchronized (mLock) {
            RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
            if (remoteMediaClient == null) {
                return;
            }
            remoteMediaClient.queueRemoveItem(mQueue.get(position).getItemId(), null);
        }
    }

    public void removeAll() {
        synchronized (mLock) {
            if (mQueue.isEmpty()) {
                return;
            }
            RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
            if (remoteMediaClient == null) {
                return;
            }
            int[] itemIds = new int[mQueue.size()];
            for (int i = 0; i < mQueue.size(); i++) {
                itemIds[i] = mQueue.get(i).getItemId();
            }
            remoteMediaClient.queueRemoveItems(itemIds, null);
            mQueue.clear();
        }
    }

    public void moveItem(int fromPosition, int toPosition) {
        if (fromPosition == toPosition) {
            return;
        }
        RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null) {
            return;
        }
        int itemId = mQueue.get(fromPosition).getItemId();

        remoteMediaClient.queueMoveItemToNewIndex(itemId, toPosition, null);
        final MediaQueueItem item = mQueue.remove(fromPosition);
        mQueue.add(toPosition, item);
    }

    public int getCount() {
        return mQueue.size();
    }

    public MediaQueueItem getItem(int position) {
        return mQueue.get(position);
    }

    public void clearQueue() {
        mQueue.clear();
        mDetachedQueue = true;
        mCurrentIem = null;
    }

    public int getRepeatMode() {
        return mRepeatMode;
    }

    public boolean isShuffleOn() {
        return mShuffle;
    }

    public MediaQueueItem getCurrentItem() {
        return mCurrentIem;
    }

    public int getCurrentItemId() {
        return mCurrentIem.getItemId();
    }

    public MediaQueueItem getUpcomingItem() {
        Timber.d("[upcoming] getUpcomingItem() returning %s", mUpcomingItem);
        return mUpcomingItem;
    }

    public void setOnQueueDataChangedListener(OnQueueDataChangedListener listener) {
        mListener = listener;
    }

    public List<MediaQueueItem> getItems() {
        return mQueue;
    }

    /**
     * Listener notifies the data of the queue has changed.
     */
    public interface OnQueueDataChangedListener {

        void onQueueDataChanged();
    }

    private void syncWithRemoteQueue() {
        RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient != null) {
            remoteMediaClient.registerCallback(mRemoteMediaClientCallback);
            MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
            if (mediaStatus != null) {
                List<MediaQueueItem> items = mediaStatus.getQueueItems();
                if (!items.isEmpty()) {
                    mQueue.clear();
                    mQueue.addAll(items);
                    mRepeatMode = mediaStatus.getQueueRepeatMode();
                    mCurrentIem = mediaStatus.getQueueItemById(mediaStatus.getCurrentItemId());
                    mDetachedQueue = false;
                    mUpcomingItem = mediaStatus.getQueueItemById(mediaStatus.getPreloadedItemId());
                }
            }
        }
    }

    private class MySessionManagerListener implements SessionManagerListener<CastSession> {

        @Override
        public void onSessionResumed(@NonNull CastSession session, boolean wasSuspended) {
            syncWithRemoteQueue();
        }

        @Override
        public void onSessionStarted(@NonNull CastSession session, @NonNull String sessionId) {
            syncWithRemoteQueue();
        }

        @Override
        public void onSessionEnded(@NonNull CastSession session, int error) {
            clearQueue();
            if (mListener != null) {
                mListener.onQueueDataChanged();
            }
        }

        @Override
        public void onSessionStarting(@NonNull CastSession session) {


            //
        }

        @Override
        public void onSessionStartFailed(@NonNull CastSession session, int error) {


            //
        }

        @Override
        public void onSessionEnding(@NonNull CastSession session) {


            //
        }

        @Override
        public void onSessionResuming(@NonNull CastSession session, @NonNull String sessionId) {


            //
        }

        @Override
        public void onSessionResumeFailed(@NonNull CastSession session, int error) {


            //
        }

        @Override
        public void onSessionSuspended(@NonNull CastSession session, int reason) {


            //
        }
    }

    private class MyRemoteMediaClientCallback extends RemoteMediaClient.Callback {

        @Override
        public void onPreloadStatusUpdated() {
            RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
            if (remoteMediaClient == null) {
                return;
            }
            MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
            if (mediaStatus == null) {
                return;
            }
            mUpcomingItem = mediaStatus.getQueueItemById(mediaStatus.getPreloadedItemId());
            Timber.d("onRemoteMediaPreloadStatusUpdated() with item=%s", mUpcomingItem);
            if (mListener != null) {
                mListener.onQueueDataChanged();
            }
        }

        @Override
        public void onQueueStatusUpdated() {
            updateMediaQueue();
            if (mListener != null) {
                mListener.onQueueDataChanged();
            }
            Timber.d("Queue was updated");
        }

        @Override
        public void onStatusUpdated() {
            updateMediaQueue();
            if (mListener != null) {
                mListener.onQueueDataChanged();
            }
        }

        private void updateMediaQueue() {
            RemoteMediaClient remoteMediaClient = getRemoteMediaClient();
            MediaStatus mediaStatus;
            List<MediaQueueItem> queueItems = null;
            if (remoteMediaClient != null) {
                mediaStatus = remoteMediaClient.getMediaStatus();
                if (mediaStatus != null) {
                    queueItems = mediaStatus.getQueueItems();
                    mRepeatMode = mediaStatus.getQueueRepeatMode();
                    mCurrentIem = mediaStatus.getQueueItemById(mediaStatus.getCurrentItemId());
                }
            }
            mQueue.clear();
            if (queueItems == null) {
                Timber.d("Queue is cleared");
            } else {
                Timber.d("Queue is updated with a list of size: %s", queueItems.size());
                if (!queueItems.isEmpty()) {
                    mQueue.addAll(queueItems);
                    mDetachedQueue = false;
                } else {
                    mDetachedQueue = true;
                }
            }
        }
    }

    private RemoteMediaClient getRemoteMediaClient() {
        CastSession castSession = CastContext.getSharedInstance(mAppContext).getSessionManager()
                .getCurrentCastSession();
        if (castSession == null || !castSession.isConnected()) {
            Timber.tag(TAG).w("Trying to get a RemoteMediaClient when no CastSession is started.");
            return null;
        }
        return castSession.getRemoteMediaClient();
    }
}
