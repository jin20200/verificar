package com.easyplexdemoapp.ui.player.fsm.concrete;



public class Vastxml {



    private Vastxml(){


    }


    public static String getAdXmlBody() {

        return null;
    }


}