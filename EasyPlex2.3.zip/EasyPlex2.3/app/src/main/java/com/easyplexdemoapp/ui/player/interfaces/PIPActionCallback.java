package com.easyplexdemoapp.ui.player.interfaces;

public interface PIPActionCallback {

    void triggerPlayOrPause(boolean play);
}
