package com.easyplexdemoapp.ui.player.interfaces;

public interface PlayerBehInterface {

    void onGenreHide(boolean clicked);
}
