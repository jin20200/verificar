package com.easyplexdemoapp.ui.player.interfaces;

public interface UiUtilities {


}
